# DoraCore Kernel Source GKI
* [**Rebase**](https://github.com/dopaemon/android_kernel_xiaomi_common/tree/Rebase)

# Downloads
* [**Release Github**](https://github.com/dopaemon/android_kernel_xiaomi_common/releases)
